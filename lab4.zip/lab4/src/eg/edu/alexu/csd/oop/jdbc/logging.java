package eg.edu.alexu.csd.oop.jdbc;

import java.io.IOException;
import java.util.logging.ConsoleHandler;
import java.util.logging.FileHandler;
import java.util.logging.Level;
import java.util.logging.LogManager;
import java.util.logging.Logger;

public class logging {
     static Logger logger = Logger.getLogger(logging.class.getName());
    logging()
    {
        Log_Method();
    }
    private static void Log_Method()
    {
        LogManager.getLogManager().reset();
        logger.setLevel(Level.ALL);

        ConsoleHandler ch=new ConsoleHandler();
        ch.setLevel(Level.WARNING);
        logger.addHandler(ch);

        try {
            FileHandler file=new FileHandler("MyLogger.log");
            file.setLevel(Level.ALL);
            logger.addHandler(file);
        } catch (SecurityException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }
    public static Logger help()//(Level x,String massage)
    {
        //Log_Method();
        //logger.log(x, massage);
        return logger;
    }

}