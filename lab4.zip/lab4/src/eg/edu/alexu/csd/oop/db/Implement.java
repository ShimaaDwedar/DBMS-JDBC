package eg.edu.alexu.csd.oop.db;

public interface Implement {

    public boolean create();

    public boolean drop();
}
