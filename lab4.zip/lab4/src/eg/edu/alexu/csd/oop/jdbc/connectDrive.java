package eg.edu.alexu.csd.oop.jdbc;

import java.sql.SQLException;

public class connectDrive {
   /* String query;
    Factory k=new Factory();

    connectDrive(String query) throws SQLException {
        this.query=query;
    }

    boolean a= k.Object(query).validation(query);
    Object res = k.Object(query).calls(query);*/

}
