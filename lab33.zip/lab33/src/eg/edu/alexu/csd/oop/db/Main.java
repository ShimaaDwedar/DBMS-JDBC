package eg.edu.alexu.csd.oop.db;

import java.sql.SQLException;
import java.util.ArrayList;

public class Main {
    public static void main(String args []) throws SQLException {
        Database k=new DB();
        DB g=new DB();
        Facade facade = new Facade();
        g.executeStructureQuery("CREATE database try");
        g.executeStructureQuery("CREATE TABLE table_name12(column_name1 varchar, column_name2 int, column_name3 varchar)");
        g.executeUpdateQuery("INSERT INTO table_name12(column_NAME1,  COLUMN_name3) VALUES ('value1','value3')");
        g.executeUpdateQuery("INSERT INTO table_name12(column_name1, COLUMN_NAME3, column_NAME2) VALUES ('ok', 'sara', 5)");
        g.executeUpdateQuery("INSERT INTO table_name12(column_name1, COLUMN_NAME3, column_NAME2) VALUES ('value3', 'value6', 6)");
        Object[][] result = g.executeQuery("SELECT * From table_name12");
        ArrayList<String>[] Base= facade.base.GetBase();
        for (int i=0; i<result.length; i++){
            for(int j=0; j<result[0].length; j++)
                System.out.print(result[i][j]+" ");
            System.out.println();
        }
    }
}
