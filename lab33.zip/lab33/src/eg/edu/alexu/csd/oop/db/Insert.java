package eg.edu.alexu.csd.oop.db;

import org.xml.sax.SAXException;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.xpath.XPathExpressionException;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

public class Insert {
    private Facade facade = new Facade();

    public void add(String query) throws ParserConfigurationException, TransformerException, SAXException, XPathExpressionException, IOException {
        ArrayList <String>[] Base= facade.base.GetBase();
        String s =facade.query.inside(query);
        String t;
        s= query.substring(query.indexOf('('),query.indexOf(')')+1);
        query=query.replace(s," ");
        if(!query.contains("(")) {
            t=s;
            s="("+Base[0].get(0);
            for(int i=1; i<Base.length; i++)
                s+=","+Base[i].get(0);
            s+=")";
        }
        else
            t= query.substring(query.indexOf('('),query.indexOf(')')+1);
        query=query.replace(t," ");

        String data[][]=facade.queryOperations.splitting(s,t);
        String []split=query.split(" ");
        String Table_name=split[2];
        addReal(Table_name,data);
    }


    private void addReal(String Table_name,String firstIn[][]) {
        ArrayList <String>[] Base= facade.base.GetBase();
        //String [][] arr = check(Base, firstIn);
        CheckValues Ch=new CheckValues();
        String [][] arr = Ch.check(firstIn);
        if(arr==null)
            System.out.println("invalid insert");
        else{
            for(int i=0;i<arr.length; i++)
                facade.base.AddToBase(i,arr[i][1]);
        }

    }

    private String[][] check (ArrayList<String>[] Base, String [][] arr){
        String [][] input = new String[arr.length][2];
        for(int i=0; i<Base.length; i++){
            int flag = 0;
            input[i][0] = Base[i].get(0);
            String first = Base[i].get(0).toLowerCase();
            for (int j=0; j<arr.length;j++){
                String sec = arr[j][0].toLowerCase();
                if(first.equals(sec)){
                    input[i][1]=arr[j][1];
                    flag=1;
                    break;
                }
            }
            if(flag==0)
                input[i][1]=null;
        }
        return input;
    }
}
